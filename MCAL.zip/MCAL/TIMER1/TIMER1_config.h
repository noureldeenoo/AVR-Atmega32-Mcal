/************************  All copyrights are reserved  **************************/
/*********************************************************************************/
/* Author    : NourEldeen                                                        */
/* Email     : noureldeen.m.abdalla@gmail.com                                    */                            
/* Version   : V01                                                               */
/* Date      : August 2022                                                       */
/*********************************************************************************/

#ifndef TIMER1_TIMER1_CONFIG_H_
#define TIMER1_TIMER1_CONFIG_H_



#endif /* TIMER1_TIMER1_CONFIG_H_ */
